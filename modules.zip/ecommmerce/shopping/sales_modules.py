# from ecommmerce.customer import 
# that is an absolute import statement example
# using absolut import is a best practice
# however if you need to simplify importing statement you can use relative importing statement

# as for relative import statement
# from ..customer import contact
# contact()

def calc_shipping():
    pass

def calc_tax():
    pass


# this code below make this file can be executed both as as a module
# as well as a script alone
# if we execute this program as a module, the code below will not be executed
# since __name__ != "main"
if __name__ == "__main__":
    print('Sales started')
    calc_tax()
