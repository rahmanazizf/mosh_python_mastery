# from sales_modules import calc_shipping, calc_tax
# import sales_modules


# # only import modules that you need
# # don't be like this
# #from sales_modules import *
# # it means that you import all the stuffs in the modules blindly
# # it may override another object with the same name in our code



# sales_modules.calc_shipping

# calc_tax()
# calc_shipping()

# import sales_modules
# import sys

# print(sys.path)

# PACKAGES
# we can gather all modules that has the same things in common
# in one place/folder
# it is called packages
# so modules are subdivision of a package

# given we already have sales_modules.py in a folder named ecommerce
# we can call that modules using the following statement

# from ecommmerce.shopping.sales_modules import calc_shipping, calc_tax
# # alternatively, if that seems a bit noisy we can use different approach
# from ecommmerce.shopping import sales_modules
# # we can simply call different modules in sales_modules as follows
# sales_modules.calc_shipping()

# # SUBMODULES

# # if we want to deivide up modules more specifically
# # we can use sub-modules
# # create a new folder in our package
# # create __init__.py file and done

from ecommmerce.shopping import sales_modules


# INTRA-PACKAGE REFERENCES
# you can take a look at sales_modules.py

# as we can see that after importing contact submodul in sales_modules
# we can use it in sales_modules
# sales_modules.calc_shipping()


# dir()
# with this function we get attributes and functions of a given object
# we can use dir() for debugging

# print(dir(sales_modules))
# print(dir(sales_modules.__name__)) # the name of given module
print(dir(sales_modules.__package__)) # the name of package
# print(dir(sales_modules.__file__)) # the file name as well as the address
